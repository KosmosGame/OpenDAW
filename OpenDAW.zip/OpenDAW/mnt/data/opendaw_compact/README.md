# OpenDAW

OpenDAW is a lightweight open-source digital audio workstation built with Python and Tkinter.

## Run

```bash
pip install -r requirements.txt
python run.py
```

## Structure

- `opendaw/track.py` — track/audio data model
- `opendaw/audio_engine.py` — playback, mixing, rendering, export
- `opendaw/app.py` — application composition
- `opendaw/core.py` — app initialization and theme
- `opendaw/timeline_edit.py` — timeline and track editing
- `opendaw/piano_drum.py` — piano roll, MIDI and drum machine
- `opendaw/plugin_chord.py` — plugins and chord maker
- `opendaw/mixer_mastering.py` — mixer and mastering windows
- `opendaw/project.py` — project persistence and undo/redo
- `opendaw/transport.py` — transport, recording and markers
- `opendaw/settings.py` — settings, effects and shortcuts

## Plugins

Place plugin `.py` files in the root `plugins/` folder.

## License

MIT
